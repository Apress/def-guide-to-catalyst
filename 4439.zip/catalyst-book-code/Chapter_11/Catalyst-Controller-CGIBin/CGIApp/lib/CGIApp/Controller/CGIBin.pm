package CGIApp::Controller::CGIBin;

use strict;
use warnings;
use parent 'Catalyst::Controller::CGIBin';

1;
