package MySchema::Result::User;

use strict;
use warnings;
use Method::Signatures::Simple;
use parent qw(DBIx::Class::Core);

__PACKAGE__->load_components('EncodedColumn');

__PACKAGE__->table('users');

__PACKAGE__->add_columns(
  name => {
    data_type => 'varchar',
  },
  password => {
    data_type => 'varchar',
    encode_column => 1,
    encode_class  => 'Crypt::Eksblowfish::Bcrypt',
    encode_check_method => 'check_password',
  },
  role => {
    data_type => 'varchar',
  }
);

__PACKAGE__->set_primary_key('name');

method restrict_User_resultset ($rs) {
  return $rs if $self->role eq 'admin';
  $rs->with_role('user');
}

1;
