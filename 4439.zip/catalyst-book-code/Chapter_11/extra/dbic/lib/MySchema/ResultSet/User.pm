package MySchema::ResultSet::User;

use strict;
use warnings;
use Method::Signatures::Simple;

use parent qw(DBIx::Class::ResultSet);

method with_role ($name) {
  $self->search({ role => $name });
}

method names () {
  map $_->name, $self->all;
}

1;
