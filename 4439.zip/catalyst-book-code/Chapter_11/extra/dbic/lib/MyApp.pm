package MyApp;

use strict;
use warnings;
use Catalyst qw(
  Authentication
);

__PACKAGE__->config(
  'Plugin::Authentication' => {
    default => {
      class => 'SimpleDB',
      user_model => 'DB::User',
      password_type => 'self_check'
    },
  },
);

__PACKAGE__->setup;

1;
