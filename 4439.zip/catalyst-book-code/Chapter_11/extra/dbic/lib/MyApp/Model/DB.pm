package MyApp::Model::DB;

use strict;
use warnings;
use Method::Signatures::Simple;
use parent qw(Catalyst::Model::DBIC::Schema);

{ our $RECURSION = 0; }

__PACKAGE__->config(
  schema_class => 'MySchema',
  connect_info => [ 't/var/test.db' ]
);

method ACCEPT_CONTEXT ($c) {
  return $self unless $c->user_exists; # assume app enforces auth/not-auth
  our $RECURSION;
  return $self if $RECURSION;
  local $RECURSION = 1;
  return $self->restrict_with_object($c->user->obj);
}

1;
