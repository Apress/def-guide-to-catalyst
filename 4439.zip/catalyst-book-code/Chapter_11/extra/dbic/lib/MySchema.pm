package MySchema;

use base qw(DBIx::Class::Schema);

__PACKAGE__->load_components('Schema::RestrictWithObject');

__PACKAGE__->load_namespaces;

1;
