package MyApp::Controller::Test;

use strict;
use warnings;
use parent qw(Catalyst::Controller);

sub test :Local {
  my ($self, $c) = @_;
  if ($c->authenticate({ user => 'bob', password => 'spoon' })) {
    $c->res->body(
      $c->model('DB')->schema->restricting_object->name
    );
  }
}

1;
