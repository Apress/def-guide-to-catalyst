package TestMySchema;

use MySchema;

use Sub::Exporter -setup => {
  exports => [ 'schema', 'table_to_aoh' ]
};

my $mistake = ', should be ResultType => \@create';
my $db = 't/var/test.db';

sub schema {
  die "Odd args to schema${mistake}" if @_ % 2;
  unlink($db) if -e $db;
  my $schema = MySchema->connect("dbi:SQLite:${db}");
  $schema->deploy;
  while (@_) {
    my ($key, $values) = (shift, shift);
    die "${values} is not an arrayref${mistake}"
      unless ref($values) eq 'ARRAY';
    $schema->resultset($key)->create($_) for @$values;
  }
  return $schema;
}

use signatures;

sub table_to_aoh ($table) {
  my ($head, @rest) = map [ split(/\s+/, $_) ], split(/\n/, $table);
  map { my %h; @h{@$head} = @$_; \%h } @rest;
}

1;
