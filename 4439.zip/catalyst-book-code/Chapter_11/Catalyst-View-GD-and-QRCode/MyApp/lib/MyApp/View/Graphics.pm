package MyApp::View::Graphics;
use strict;
use warnings;
use base 'Catalyst::View::GD';
1;
