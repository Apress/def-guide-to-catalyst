   package MailerExample::UI::Widget::Sent;
   use Reaction::UI::WidgetClass;

   use namespace::clean -except => 'meta';

   1;
