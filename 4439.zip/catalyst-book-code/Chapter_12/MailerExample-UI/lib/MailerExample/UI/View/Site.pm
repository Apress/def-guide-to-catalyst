   package MailerExample::UI::View::Site;
   use Reaction::Class;

   use namespace::clean -except => 'meta';

   extends 'Reaction::UI::View::TT';

   1;
