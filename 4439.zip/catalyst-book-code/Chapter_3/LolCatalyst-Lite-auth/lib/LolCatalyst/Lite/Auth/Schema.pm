package LolCatalyst::Lite::Auth::Schema;

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_classes;


# Created by DBIx::Class::Schema::Loader v0.04005 @ 2008-09-25 15:39:16
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:Rkei1Ki7B8IVeXUbhN17jQ


# You can replace this text with custom content, and it will be preserved on regeneration
1;
