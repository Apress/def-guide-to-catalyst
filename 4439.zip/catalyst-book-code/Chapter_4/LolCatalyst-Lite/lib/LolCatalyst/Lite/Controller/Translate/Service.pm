package LolCatalyst::Lite::Controller::Translate::Service;

use strict;
use warnings;
use parent qw(LolCatalyst::Lite::Controller::Translate);

__PACKAGE__->config(
  current_view => 'Service',
  actions => {
    base => {
      PathPart => 'translate/service'
    },
  },
);

1;
